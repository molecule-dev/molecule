import { expect, test } from '@playwright/test'

test('should count role locators', async ({ page }) => {
  await page.goto('/')
  const count = await page.getByRole('button', { name: 'Post Comment' }).count()
  expect(count).toBe(3)
})
