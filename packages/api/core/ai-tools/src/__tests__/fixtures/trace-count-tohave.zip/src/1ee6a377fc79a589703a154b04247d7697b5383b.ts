import { expect, test } from '@playwright/test'

test('should display multiple comments (toHaveCount)', async ({ page }) => {
  await page.goto('/')
  await expect(page.locator('.card:not(.comment-form) .card-block')).toHaveCount(3)
})
