import { createServer, type Server } from 'node:http'

import { expect, test } from '@playwright/test'

let server: Server
let base = ''

const page_html = `<!doctype html><html><body>
<button id="go">Follow</button><button id="go-raw">Raw</button><span id="state">signed out</span>
<script>
const send = (url, headers) => async () => {
  await fetch(url, { headers }).catch(() => {})
  window.__done = true
}
document.getElementById('go').addEventListener('click', () => {
  const url = document.body.dataset.endpoint
  send(url, { Authorization: 'Bearer secret-token-abc123' })()
})
document.getElementById('go-raw').addEventListener('click', () => {
  send('/api/raw', { Authorization: 'rawtokenvalue-not-a-scheme' })()
})
</script></body></html>`

test.beforeAll(async () => {
  server = createServer((req, res) => {
    const url = new URL(req.url ?? '/', 'http://127.0.0.1')
    if (url.pathname === '/api/bearer' || url.pathname === '/api/raw') {
      res.writeHead(401, { 'content-type': 'application/json' })
      res.end(JSON.stringify({ errors: { token: ['is invalid'] } }))
      return
    }
    if (url.pathname === '/api/forbidden') {
      res.writeHead(403, { 'content-type': 'application/json' })
      res.end(JSON.stringify({ errors: { detail: 'not allowed' } }))
      return
    }
    res.writeHead(200, { 'content-type': 'text/html' })
    res.end(page_html)
  })
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve))
  const address = server.address()
  base = typeof address === 'object' && address ? `http://127.0.0.1:${address.port}` : ''
})

test.afterAll(async () => {
  await new Promise<void>((resolve) => server.close(() => resolve()))
})

const clickAndFail = async (page: import('@playwright/test').Page, endpoint: string) => {
  await page.goto(base + '/')
  await page.evaluate((e) => { document.body.dataset.endpoint = e }, endpoint)
  const response = page.waitForResponse((r) => r.url().includes(endpoint))
  await page.click(endpoint === '/api/raw' ? '#go-raw' : '#go')
  await response
  await page.waitForFunction(() => (window as unknown as { __done?: boolean }).__done === true)
  expect(await page.locator('#state').textContent()).toBe('favorited')
}

test('sends a bearer token and is refused with 401', async ({ page }) => {
  await clickAndFail(page, '/api/bearer')
})

test('sends a bearer token and is refused with 403', async ({ page }) => {
  await clickAndFail(page, '/api/forbidden')
})

test('sends an Authorization value with no scheme', async ({ page }) => {
  await clickAndFail(page, '/api/raw')
})
