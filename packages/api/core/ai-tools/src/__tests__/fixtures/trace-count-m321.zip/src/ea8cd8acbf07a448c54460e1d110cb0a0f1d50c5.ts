import { expect, test } from '@playwright/test'

test('should display multiple comments', async ({ page }) => {
  await page.goto('/')
  const count = await page.locator('.card:not(.comment-form) .card-block').count()
  expect(count).toBe(3)
})
