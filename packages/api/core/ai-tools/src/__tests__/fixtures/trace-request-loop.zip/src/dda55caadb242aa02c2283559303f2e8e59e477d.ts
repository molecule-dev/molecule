import { expect, test } from '@playwright/test'

test('should follow a user', async ({ page }) => {
  await page.goto('/')
  await page.getByRole('button', { name: 'Follow testuser' }).click()
  await expect(page.getByRole('button', { name: 'Unfollow testuser' })).toBeVisible({
    timeout: 1500,
  })
})
