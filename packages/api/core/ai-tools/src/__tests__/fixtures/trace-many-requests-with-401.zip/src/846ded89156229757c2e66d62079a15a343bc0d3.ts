import { createServer } from 'node:http'
import type { AddressInfo } from 'node:net'

import { expect, test } from '@playwright/test'

/** A tiny app: `/` is a page, `/api/fail` answers 401, everything else 200. */
async function app(): Promise<{ origin: string; close: () => Promise<void> }> {
  const server = createServer((req, res) => {
    if (req.url === '/api/fail') {
      res.statusCode = 401
      res.setHeader('content-type', 'application/json')
      res.end('{"error":"unauthorized"}')
      return
    }
    if (req.url === '/') {
      res.setHeader('content-type', 'text/html')
      res.end('<html><body>app</body></html>')
      return
    }
    res.setHeader('content-type', 'application/json')
    res.end('{}')
  })
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve))
  const { port } = server.address() as AddressInfo
  return { origin: `http://127.0.0.1:${port}`, close: () => new Promise((r) => server.close(() => r())) }
}

test('a request still pending when the test ends is left with no response', async ({ page }) => {
  const hang = createServer(() => {})
  await new Promise<void>((resolve) => hang.listen(0, '127.0.0.1', resolve))
  const { port } = hang.address() as AddressInfo
  await page.setContent('<html><body>pending</body></html>')
  await page.evaluate((p) => {
    void fetch(`http://127.0.0.1:${p}/api/tags`).catch(() => {})
  }, port)
  await page.waitForTimeout(400)
  hang.close()
  expect(true).toBe(true)
})

test('a refused connection is a real failure with its error text', async ({ page }) => {
  const server = await app()
  // A port that was open a moment ago and is now closed: the fetch is refused.
  const spare = createServer(() => {})
  await new Promise<void>((resolve) => spare.listen(0, '127.0.0.1', resolve))
  const { port } = spare.address() as AddressInfo
  await new Promise<void>((resolve) => spare.close(() => resolve()))
  await page.goto(server.origin + '/')
  const error = await page.evaluate(async (p) => {
    try {
      await fetch(`http://127.0.0.1:${p}/sw.js`)
      return 'no error'
    } catch (e) {
      return String(e)
    }
  }, port)
  expect(error).toContain('TypeError')
  await server.close()
})

test('a failed request survives a page that made more requests than the read keeps', async ({ page }) => {
  const server = await app()
  await page.goto(server.origin + '/')
  const statuses = await page.evaluate(async () => {
    const out: number[] = []
    for (const path of ['/api/fail', '/api/a', '/api/b', '/api/c', '/api/d', '/api/e', '/api/f']) {
      out.push((await fetch(path)).status)
    }
    return out
  })
  expect(statuses[0]).toBe(401)
  await server.close()
})
