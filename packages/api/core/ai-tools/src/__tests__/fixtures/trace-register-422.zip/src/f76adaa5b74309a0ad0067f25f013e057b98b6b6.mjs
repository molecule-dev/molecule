import http from 'node:http'
import { chromium } from '/home/l/Repos/molecule-workspace/node_modules/playwright/index.mjs'

const server = http.createServer((req, res) => {
  if (req.url === '/') {
    res.writeHead(200, { 'content-type': 'text/html' })
    res.end('<html><body><h1>hi</h1></body></html>')
    return
  }
  let body = ''
  req.on('data', (c) => (body += c))
  req.on('end', () => {
    res.writeHead(422, { 'content-type': 'application/json' })
    res.end(JSON.stringify({ errors: { username: ["can't be blank"], email: ["can't be blank"] } }))
  })
})
await new Promise((r) => server.listen(0, '127.0.0.1', r))
const port = server.address().port
const browser = await chromium.launch()
const context = await browser.newContext()
await context.tracing.start({ screenshots: true, snapshots: true, sources: true })
const page = await context.newPage()
await page.goto(`http://127.0.0.1:${port}/`)
const status = await page.evaluate(async () => {
  const r = await fetch('/api/users', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ data: { user: { username: 'x', email: 'x@y.z', password: 'secret-pw' } } }) })
  const text = await r.text()
  return r.status + ' ' + text.slice(0, 20)
})
console.log('status', status)
await page.waitForTimeout(200)
await context.tracing.stop({ path: 'trace-422b.zip' })
await browser.close()
server.close()
